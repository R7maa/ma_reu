
export default data = [
{
    id : 1 ,
    jour : 'lundi' ,
    heure_reunion : '14h00',
    lieu_reunion : 'salle B',
    sujet_reunion : 'recherche de nouveaux partenaires',
    listes_participants : 'alainLamzon@gmail.com ,marthLamzon18@gmail.com, paulLamzon@gmail.com'
},
{
    id : 2,
    jour : 'Jeudi' ,
    heure_reunion : '16h00',
    lieu_reunion : 'george',
    sujet_reunion : 'plan d\'action',
    listes_participants : 'alouLamzon@gmail.com ,martinLamzon18@gmail.com ,mariLamzon@gmail.com ,mamiLamzo@gmail.com' 
},
{
    id : 3,
    jour : 'lundi' ,
    heure_reunion : '18h00',
    lieu_reunion : 'bt',
    sujet_reunion : 'dernier sprint',
    listes_participants : 'alainLamzon@gmail.com, marthLamzon18@gmail.com ,paulLamzon@gmail.com'
},

{
    id : 4,
    jour : 'lundi' ,
    heure_reunion : '11h00',
    lieu_reunion : 'plia',
    sujet_reunion : 'projet b',
    listes_participants : 'alainLamzon@gmail.com marthLamzon18@gmail.com paulLamzon@gmail.com'
}
   


]

