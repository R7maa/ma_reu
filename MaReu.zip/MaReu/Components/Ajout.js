import React from 'react'
import { Text, View, StyleSheet, Image ,TextInput ,Button } from 'react-native';

class Ajout extends React.Component {

    render(){
        return(
            <View>
             <Text>Ajouter une réunion</Text>
            <TextInput name='lieu' placeholder='Lieu de la reunion'/>
            <TextInput name='motif' placeholder='sujet de la reunion'/>
            
            <Button title='Ajouter une réunion' onPress={() => {}}/>
           </View>

        )
    }
}
export default Ajout