import React from 'react'
import { Text, View, StyleSheet, Image } from 'react-native';
import {FlatList } from 'react-native'
import reunions from '../Donnees/reunions'


class MyHeader extends React.Component {
    render() {
      
        const reunion = this.props.reunion
        return(
            
            <View style={styles.main_container}>
        
        <View style={styles.content_container}>
          <View style={styles.header_container}>
            <Text style={styles.title_text}>{reunions.jour}</Text>
            <Text style={styles.vote_text}>{reunions.heure_reunion}</Text>
          </View>
          <View style={styles.description_container}>
            <Text style={styles.description_text} numberOfLines={6}>{reunions.lieu_reunion}</Text>
            <Text style={styles.description_text} numberOfLines={6}>{reunions.sujet_reunion}</Text>
          </View>
          <View style={styles.date_container}>
            <Text style={styles.date_text}>Sorti le {reunions.listes_participants}</Text>
          </View>
        </View>
        <FlatList
     data={reunions}
     keyExtractor={(item) => item.id.toString()}
      renderItem={({item}) => <Text>{item.title}</Text>}
   />
      </View>
        )
    }
    }