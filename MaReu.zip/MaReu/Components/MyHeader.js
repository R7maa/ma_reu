import React from 'react'
import { Text, View, StyleSheet, Image } from 'react-native';

class MyHeader extends React.Component {
    render() {
        return(
            <View>
                <Text style={styles.paragraph}>
                 Ma réu  </Text>
            </View>
        )
    }
    
}
const styles = StyleSheet.create({
    paragraph: {
        
        width: 360,
        backgroundColor: 'blue',
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
      },

    });


export default MyHeader