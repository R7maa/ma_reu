import* as React from 'react';
import MyHeader from './Components/MyHeader'
import Liste from './Components/Liste'
import reunions from '../Donnees/reunions'
import { View ,StyleSheet } from 'react-native';
import Constants from 'expo-constants';



export default function App() {
  return (
         < View style={styles.container}>

           <MyHeader/>
           <Liste/>
         </View>
       
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 100 ,
    marginLeft : 340,
    width: 380,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    padding: 8,
  }
  });